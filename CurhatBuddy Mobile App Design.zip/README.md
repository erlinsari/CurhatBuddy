
  # CurhatBuddy Mobile App Design

  This is a code bundle for CurhatBuddy Mobile App Design. The original project is available at https://www.figma.com/design/KQz6yiCYBNZJgqoE1JLWty/CurhatBuddy-Mobile-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  